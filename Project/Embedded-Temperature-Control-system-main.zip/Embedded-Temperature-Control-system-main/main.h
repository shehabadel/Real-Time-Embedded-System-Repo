void GPIO_init(void);
void printchar(char);
void print(char*);
void TASK1(void *);
void TASK2(void*);
void TASK3(void*);
void TASK4(void*);