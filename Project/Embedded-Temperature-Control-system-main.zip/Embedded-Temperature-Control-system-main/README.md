# Embedded-Temperature-Control-system
An ON-OFF temperature controller application applied on Arm Cortex M4 TivaC using FreeRTOS by taking feedback from the temperature sensor to maintain the setpoint through Queues to send data between tasks and making a communication between the user through terminal to adjust desired setpoint and display the measured temperature on the LCD.
